package com.example.ipcamerastream
import fi.iki.elonen.NanoHTTPD
interface CameraController{fun switch();fun torch(on:Boolean);fun zoom(v:Float)}
class CameraServer(port:Int,private val c:CameraController):NanoHTTPD(port){
 override fun serve(s:IHTTPSession):Response{ val p=s.parameters; when(s.uri){"/api/camera"->c.switch();"/api/torch"->c.torch(p["on"]?.firstOrNull()?.toBoolean()?:false);"/api/zoom"->c.zoom(p["value"]?.firstOrNull()?.toFloatOrNull()?:0f)}
  return newFixedLengthResponse(Response.Status.OK,"text/html; charset=utf-8",html()) }
 private fun html()="""<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1"><title>IP Camera</title><style>body{margin:0;background:#111;color:#fff;font-family:Arial;text-align:center}img{width:100%;max-height:75vh;object-fit:contain;background:#000}.c{padding:12px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap}button,input{font-size:18px;padding:10px;border-radius:8px;border:0}</style></head><body><h2>IP Camera WebCam</h2><img src="/stream"><div class=c><button onclick="fetch('/api/camera')">Switch Camera</button><button onclick="fetch('/api/torch?on=true')">Torch ON</button><button onclick="fetch('/api/torch?on=false')">Torch OFF</button><label>Zoom <input type=range min=0 max=1 step=.01 value=0 oninput="fetch('/api/zoom?value='+this.value)"></label></div><p>For OBS use this page as a Browser Source. For HDMI, use USB-C DisplayPort/HDMI output plus an HDMI capture card.</p></body></html>"""
}
