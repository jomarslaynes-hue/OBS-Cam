package com.example.ipcamerastream

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.widget.*
import java.net.NetworkInterface
import java.util.Collections

class MainActivity : AppCompatActivity() {
 private lateinit var preview: PreviewView; private lateinit var status: TextView
 private var camera: Camera?=null; private var provider: ProcessCameraProvider?=null; private var front=false; private var torch=false
 private val server by lazy { CameraServer(8080, object: CameraController { override fun switch(){ front=!front; startCamera() }; override fun torch(on:Boolean){ torch=on; camera?.cameraControl?.enableTorch(on) }; override fun zoom(v:Float){ camera?.cameraControl?.setLinearZoom(v.coerceIn(0f,1f)) } }) }
 private val permission=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ startCamera() }
 override fun onCreate(b:Bundle?){ super.onCreate(b); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); setContentView(R.layout.activity_main)
  preview=findViewById(R.id.preview); status=findViewById(R.id.status)
  findViewById<Button>(R.id.switchCamera).setOnClickListener{front=!front;startCamera()}
  findViewById<Button>(R.id.torch).setOnClickListener{torch=!torch;camera?.cameraControl?.enableTorch(torch)}
  findViewById<Button>(R.id.hdmi).setOnClickListener{ preview.systemUiVisibility=0; Toast.makeText(this,"HDMI Output Mode: connect USB-C DisplayPort/HDMI to a capture card if supported by your phone.",Toast.LENGTH_LONG).show() }
  val needed= arrayOf(Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO)
  if(needed.all{ContextCompat.checkSelfPermission(this,it)==PackageManager.PERMISSION_GRANTED}) startCamera() else permission.launch(needed)
  server.start()
 }
 private fun startCamera(){ val f=ProcessCameraProvider.getInstance(this); f.addListener({ provider=f.get(); val sel=if(front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
   val p=Preview.Builder().build().also{it.surfaceProvider=preview.surfaceProvider}
   val a=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
   a.setAnalyzer(ContextCompat.getMainExecutor(this)){it.close()}
   provider?.unbindAll(); camera=provider?.bindToLifecycle(this,sel,p,a); camera?.cameraControl?.enableTorch(torch)
   status.text="IP Camera • http://${localIp()}:8080" },ContextCompat.getMainExecutor(this)) }
 private fun localIp():String=try{Collections.list(NetworkInterface.getNetworkInterfaces()).flatMap{Collections.list(it.inetAddresses)}.firstOrNull{!it.isLoopbackAddress && it.hostAddress?.contains(":")==false}?.hostAddress ?: "0.0.0.0"}catch(_:Exception){"0.0.0.0"}
 override fun onDestroy(){server.stop();super.onDestroy()}
}
