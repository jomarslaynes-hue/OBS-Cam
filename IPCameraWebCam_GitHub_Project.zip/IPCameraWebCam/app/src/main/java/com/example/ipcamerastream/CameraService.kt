package com.example.ipcamerastream
import android.app.Service
import android.content.Intent
import android.os.IBinder
class CameraService:Service(){ override fun onBind(intent:Intent?):IBinder?=null }
