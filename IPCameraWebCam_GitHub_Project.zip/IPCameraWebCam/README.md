# IP Camera WebCam for OBS

Android app project for turning a phone into a LAN IP camera with browser control and an HDMI-output workflow for OBS.

## Features in this starter
- CameraX rear/front camera preview
- Browser control page on port 8080
- Camera switching, torch, zoom control
- Full-screen preview suitable for USB-C DisplayPort/HDMI capture workflows
- OBS Browser Source workflow
- Android Studio + Kotlin + Gradle project

## OBS network workflow
Phone and PC on the same Wi-Fi/LAN:

`http://PHONE_IP:8080/`

Add the URL as an OBS Browser Source.

## HDMI workflow
`Android phone -> USB-C DisplayPort/HDMI adapter -> HDMI capture card -> USB -> OBS`

The phone must support USB-C DisplayPort Alt Mode. A USB-C-to-HDMI adapter is normally video OUTPUT, not HDMI INPUT.

## USB webcam limitation
A normal USB-C-to-USB-B cable does not automatically make every Android phone a UVC webcam. True UVC device mode requires device/Android/kernel support. The network IP-camera method is the portable fallback.

## Next production work
The architecture is intentionally ready to extend with a ForegroundService, H.264/WebRTC low-latency streaming, microphone audio, authentication, resolution/FPS selection, bitrate controls, and native UVC support where hardware permits.
